/* 
 * File:   timers.h
 * Author: sahil
 *
 * Created on 2 December, 2020, 8:28 PM
 */

#ifndef TIMERS_H
#define	TIMERS_H

void init_timer2(void);

#endif	/* TIMERS_H */

